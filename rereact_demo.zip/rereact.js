
function Button(children, { onClick }) {
    const btn = document.createElement("button");
    btn.textContent = children;
    btn.onclick = onClick;
    return btn;
}

function Span(children) {
    const span = document.createElement("span");
    span.textContent = children;
    return span;
}

let root;
let app;

function createRoot(container, component) {
    root = container;
    app = component;
    render();
}

function render() {
    root.replaceChildren();
    let elements = app();
    elements.forEach(element => root.appendChild(element));
}

let _state;
function useState(initialValue) {
    _state = _state || initialValue;
    function setState(newVal) {
        if (_state !== newVal) {
            _state = newVal;
            render();
        }
    }
    return [_state, setState];
}