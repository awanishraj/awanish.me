function CounterApp() {

    let [counter, setCounter] = useState(0);

    return [
        Button("Dec", { onClick: () => setCounter(counter - 1) }),
        Span(counter),
        Button("Inc", { onClick: () => setCounter(counter + 1) }),
    ]
}

let container = document.getElementById("container");
createRoot(container, CounterApp);